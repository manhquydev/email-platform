(function(){const w=['input[type="email"]','input[name*="email" i]','input[id*="email" i]','input[placeholder*="email" i]','input[autocomplete="email"]'];function b(){const t=[],e=new Set;for(const o of w)document.querySelectorAll(o).forEach(n=>{e.has(n)||x(n)&&(n.disabled||n.readOnly||(e.add(n),t.push({element:n,id:n.id||n.name||`ephemera-${t.length}`,rect:n.getBoundingClientRect()})))});return t}function x(t){const e=getComputedStyle(t);if(e.display==="none"||e.visibility==="hidden"||parseFloat(e.opacity)===0)return!1;const o=t.getBoundingClientRect();return!(o.width===0||o.height===0)}function v(t){const e=new MutationObserver(()=>{const o=b();o.length>0&&t(o)});return e.observe(document.body,{childList:!0,subtree:!0}),()=>e.disconnect()}const p=24,m=new WeakSet;function h(t){t.forEach(e=>{if(m.has(e.element))return;m.add(e.element);const o=y(e.element);E(o,e.element),o.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),C(e.element,o)})})}function y(t){const e=document.createElement("div");e.className="ephemera-icon-container",e.style.cssText=`
    position: absolute;
    z-index: 999999;
    cursor: pointer;
    width: ${p}px;
    height: ${p}px;
  `;const o=e.attachShadow({mode:"closed"}),i=document.createElement("style");i.textContent=`
    .icon {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #0ea5e9;
      border-radius: 4px;
      opacity: 0.8;
      transition: opacity 0.2s;
      box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    .icon:hover {
      opacity: 1;
    }
    .icon svg {
      width: 16px;
      height: 16px;
      stroke: white;
    }
  `;const n=document.createElement("div");return n.className="icon",n.innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <rect width="20" height="16" x="2" y="4" rx="2"/>
  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
</svg>`,o.appendChild(i),o.appendChild(n),document.body.appendChild(e),e}function E(t,e){const o=()=>{const n=e.getBoundingClientRect();if(n.width===0||n.height===0){t.style.display="none";return}else t.style.display="block";const c=window.scrollX,s=window.scrollY;t.style.top=`${n.top+s+(n.height-p)/2}px`,t.style.left=`${n.right+c-p-8}px`};o(),window.addEventListener("scroll",o,{passive:!0}),window.addEventListener("resize",o,{passive:!0}),new ResizeObserver(o).observe(e)}let a=null;function C(t,e){a&&(a.remove(),a=null),chrome.storage.local.get(["inboxes"],o=>{const i=o.inboxes||[],n=k(i,t);document.body.appendChild(n),a=n;const c=e.getBoundingClientRect();n.style.top=`${c.bottom+window.scrollY+4}px`,n.style.left=`${c.right+window.scrollX-200}px`;const s=r=>{!n.contains(r.target)&&r.target!==e&&(n.remove(),a=null,document.removeEventListener("click",s))};setTimeout(()=>document.addEventListener("click",s),0)})}function k(t,e){const o=document.createElement("div");o.style.cssText=`
    position: absolute;
    z-index: 9999999;
    width: 220px;
    max-height: 300px;
    overflow-y: auto;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    font-family: system-ui, sans-serif;
  `;const i=o.attachShadow({mode:"closed"}),n=document.createElement("style");n.textContent=`
    .item {
      padding: 10px 12px;
      color: #334155;
      font-size: 13px;
      cursor: pointer;
      border-bottom: 1px solid #f1f5f9;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: background-color 0.1s;
    }
    .item:hover {
      background: #f8fafc;
    }
    .item:last-child {
      border-bottom: none;
    }
    .create {
      color: #0ea5e9;
      font-weight: 600;
      background: #f0f9ff;
    }
    .create:hover {
      background: #e0f2fe;
    }
    .header {
        padding: 8px 12px;
        font-size: 11px;
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        background: #f8fafc;
    }
  `;const c=document.createElement("div");if(t.length>0){const r=document.createElement("div");r.className="header",r.textContent="Your Inboxes",c.appendChild(r),t.slice(0,5).forEach(d=>{const l=`${d.localPart}@${d.domain.name}`,u=document.createElement("div");u.className="item",u.textContent=l,u.addEventListener("click",()=>f(e,l)),c.appendChild(u)})}const s=document.createElement("div");return s.className="item create",s.innerHTML="+ Generate New Email",s.addEventListener("click",()=>{s.textContent="Generating...",chrome.runtime.sendMessage({type:"CREATE_INBOX"},r=>{if(r&&r.success&&r.inbox){const d=r.inbox,l=d.address||`${d.localPart}@${d.domain.name}`;f(e,l)}else s.textContent="Error creating email",s.style.color="red"})}),c.appendChild(s),i.appendChild(n),i.appendChild(c),o}function f(t,e){a&&(a.remove(),a=null),t.value=e,t.focus(),t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0}))}console.log("Ephemera: Content script loaded");async function g(){const t=b();t.length>0&&(console.log(`Ephemera: Found ${t.length} email fields`),h(t)),v(e=>{e.length>0&&(console.log(`Ephemera: Found ${e.length} new email fields`),h(e))})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",g):g();
})()
